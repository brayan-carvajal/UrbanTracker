﻿namespace Entity.Enum
{
    public enum GenderEmun
    {
        Masculino,
        Femenino,
        otro
    }
}
