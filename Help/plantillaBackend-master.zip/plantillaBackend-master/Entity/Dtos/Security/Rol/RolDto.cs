﻿using Entity.Dtos.Global;

namespace Entity.Dtos.Security.Rol
{
    public class RolDto : ABaseDto
    {
        public string Name { get; set; }
        public string Description { get; set; }

    }
}
