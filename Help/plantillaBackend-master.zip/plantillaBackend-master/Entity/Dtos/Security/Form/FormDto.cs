﻿using Entity.Dtos.Global;

namespace Entity.Dtos.Security.Form
{
    public class FormDto : ABaseDto
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
