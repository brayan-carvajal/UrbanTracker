﻿namespace Entity.Dtos.Security.Auth
{
    public class AuthDto
    {
        public string Token { get; set; }
        public DateTime Expiracion { get; set; }
    }
}
