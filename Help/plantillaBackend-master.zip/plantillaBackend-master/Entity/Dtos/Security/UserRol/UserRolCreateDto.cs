﻿namespace Entity.Dtos.Security.UserRol
{
    public class UserRolCreateDtos
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int RolId { get; set; }
    }
}
